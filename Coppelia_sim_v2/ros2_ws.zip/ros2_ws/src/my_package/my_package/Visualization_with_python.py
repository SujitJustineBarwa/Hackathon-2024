from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import time
import matplotlib.pyplot as plt

class coppelia:

    def __init__(self):

        client = RemoteAPIClient()
        sim = client.require('sim')
        self.sim = sim

        self.base_handle = sim.getObject('/Base')

        self.left_joint_handle = sim.getObject('/Left_joint')
        self.right_joint_handle = sim.getObject('/Right_joint')

        self.left_TOF_handle =  sim.getObject('/Left_TOF')
        self.front_TOF_handle =  sim.getObject('/Front_TOF')
        self.right_TOF_handle =  sim.getObject('/Right_TOF') 
        self.back_TOF_handle =  sim.getObject('/Back_TOF') 

        self.data_list = ['left_wheel_angular_velocity',
                          'right_wheel_angular_velocity',
                          'yaw_rate_reading',
                          'front_TOF_reading',
                          'left_TOF_reading',
                          'right_TOF_reading',
                          'back_TOF_reading']

    def get_data(self):
        left_wheel_jointAngVel = self.sim.getJointVelocity(self.left_joint_handle)
        right_wheel_jointAngVel = self.sim.getJointVelocity(self.right_joint_handle)

        linear_velocity, angular_velocity = self.sim.getObjectVelocity(self.base_handle)
        yaw_rate = angular_velocity[2]

        res,left_distance,_,_,_ = self.sim.readProximitySensor(self.left_TOF_handle)
        if res == -1:
            left_distance = float(-1)

        res,right_distance,_,_,_ = self.sim.readProximitySensor(self.right_TOF_handle)
        if res == -1:
            right_distance = float(-1)

        res,front_distance,_,_,_ = self.sim.readProximitySensor(self.front_TOF_handle)
        if res == -1:
            front_distance = float(-1)

        res,back_distance,_,_,_ = self.sim.readProximitySensor(self.back_TOF_handle)
        if res == -1:
            back_distance = float(-1)

        data = {'left_wheel_angular_velocity' : left_wheel_jointAngVel,
                'right_wheel_angular_velocity' : right_wheel_jointAngVel,
                'yaw_rate_reading' : yaw_rate,
                'front_TOF_reading' : front_distance,
                'left_TOF_reading' : left_distance,
                'right_TOF_reading' : right_distance,
                'back_TOF_reading' : back_distance,
        }

        return data

    
    def set_left_wheel_speed(self,vel_left):
        self.sim.setJointTargetVelocity(self.left_joint_handle,vel_left)

    def set_right_wheel_speed(self,vel_right):
        self.sim.setJointTargetVelocity(self.right_joint_handle,vel_right)




def live_graph(bot):
    plt.ion()
    fig, ax = plt.subplots(4, 1, figsize=(10, 8))

    x_data = []
    left_wheel_vel_data = []
    right_wheel_vel_data = []
    yaw_rate_data = []
    front_tof_data = []
    left_tof_data = []
    right_tof_data = []
    back_tof_data = []

    start_time = time.time()

    while True:
        bot.set_left_wheel_speed(0.5)
        bot.set_right_wheel_speed(-0.5)
        data = bot.get_data()

        current_time = time.time() - start_time
        x_data.append(current_time)
        left_wheel_vel_data.append(data['left_wheel_angular_velocity'])
        right_wheel_vel_data.append(data['right_wheel_angular_velocity'])
        yaw_rate_data.append(data['yaw_rate_reading'])
        front_tof_data.append(data['front_TOF_reading'])
        left_tof_data.append(data['left_TOF_reading'])
        right_tof_data.append(data['right_TOF_reading'])
        back_tof_data.append(data['back_TOF_reading'])

        ax[0].cla()
        ax[0].plot(x_data, left_wheel_vel_data, label='Left Wheel Velocity')
        ax[0].plot(x_data, right_wheel_vel_data, label='Right Wheel Velocity')
        ax[0].legend()
        ax[0].set_ylabel('Wheel Velocity')

        ax[1].cla()
        ax[1].plot(x_data, yaw_rate_data, label='Yaw Rate')
        ax[1].legend()
        ax[1].set_ylabel('Yaw Rate')

        ax[2].cla()
        ax[2].plot(x_data, front_tof_data, label='Front TOF')
        ax[2].plot(x_data, left_tof_data, label='Left TOF')
        ax[2].plot(x_data, right_tof_data, label='Right TOF')
        ax[2].plot(x_data, back_tof_data, label='Back TOF')
        ax[2].legend()
        ax[2].set_ylabel('TOF Readings')

        ax[3].cla()
        ax[3].bar(['Front', 'Left', 'Right', 'Back'], [front_tof_data[-1], left_tof_data[-1], right_tof_data[-1], back_tof_data[-1]])
        ax[3].set_ylabel('TOF Readings')

        plt.pause(0.1)

# Create an instance of the Coppelia class
bot = coppelia()

# Start the live graph
try:
    live_graph(bot)
except KeyboardInterrupt:
    # Stop the robot if the program is interrupted
    bot.set_left_wheel_speed(1)
    bot.set_right_wheel_speed(-1)
    print("Program interrupted, robot stopped.")
